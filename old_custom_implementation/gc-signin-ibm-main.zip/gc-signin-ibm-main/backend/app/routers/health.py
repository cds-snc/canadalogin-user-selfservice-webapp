"""Health-related endpoints."""

from fastapi import APIRouter
from pydantic import BaseModel, Field
from datetime import datetime

API_VERSION = "1.0.0"


class HealthResponse(BaseModel):
    status: str = Field(..., description="Service health status")
    timestamp: str = Field(..., description="Todays date")
    service: str = Field(..., description="Service name")


router = APIRouter()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health Check",
    description="Returns the health status of the service",
)
async def health_check():
    """
    Health check endpoint to monitor service status.

    This endpoint can be used by monitoring tools to check if the service is running properly.

    Returns:
        HealthResponse: Service health information including status and timestamp
    """
    return {
        "status": "healthy",
        "timestamp": datetime.today().strftime("%Y-%m-%d %H:%M:%S"),
        "service": "gc-signin-backend",
    }
