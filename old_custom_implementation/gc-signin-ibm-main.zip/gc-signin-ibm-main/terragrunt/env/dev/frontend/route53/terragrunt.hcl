include "root" {
  path = find_in_parent_folders("root.hcl")
}

terraform {
  source = "../../../../aws/frontend/route53"
}